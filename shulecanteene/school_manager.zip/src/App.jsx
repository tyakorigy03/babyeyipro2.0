import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { 
  Layout 
} from './components/layout';

import './index.css';

import Home from './pages/index';
import Staff from './pages/staff';
import StaffCreate from './pages/staff_create';
import OrganisationStructure from './pages/organisation_structure';
import Students from './pages/students';
import StudentCreate from './pages/student_create';
import StudentEnrollment from './pages/student_enrollment';
import Parents from './pages/parents';
import ParentCreate from './pages/parent_create';
import AttendanceHub from './pages/attendance_hub';
import AttendanceStudents from './pages/attendance';
import AttendanceStaff from './pages/attendance_staff';
import AttendanceConfig from './pages/attendance_config';
import Timetable from './pages/timetable';
import SchoolDays from './pages/school_days';

const staffNavItems = [
  { label: 'Staff Members', path: '/staff' },
  { label: 'Organisation Structure', path: '/staff/organisation-structure' },
  { label: 'Staff Reports', path: '/staff/reports' },
];

const studentNavItems = [
  { label: 'All Students', path: '/students' },
  { label: 'Parent Portal', path: '/students/parents' },
  { label: 'Enrollment', path: '/students/enroll' },
];

const attendanceNavItems = [
  { label: 'Student Attendance', path: '/attendance/students' },
  { label: 'Staff Attendance', path: '/attendance/staff' },
  { label: 'Configurations', path: '/attendance/config' },
];

const academicNavItems = [
  { label: 'Weekly Timetable', path: '/academic/timetable' },
  { label: 'School Days Config', path: '/academic/school-days' },
];

function AppContent() {
  const location = useLocation();
  const isHome = location.pathname === '/';
  const isStaff = location.pathname.startsWith('/staff');
  const isStudents = location.pathname.startsWith('/students');
  const isAttendance = location.pathname.startsWith('/attendance');
  const isAcademic = location.pathname.startsWith('/academic');

  let navItems = [];
  if (isStaff) navItems = staffNavItems;
  else if (isStudents) navItems = studentNavItems;
  else if (isAttendance) navItems = attendanceNavItems;
  else if (isAcademic) navItems = academicNavItems;
  else if (!isHome) navItems = [{ label: 'Dashboard', path: '/' }];

  const title = isStaff ? "Staff" : isStudents ? "Students" : isAttendance ? "Attendance" : isAcademic ? "Timetable" : "";

  return (
    <Layout 
      userName="Alex Johnson" 
      isHome={isHome} 
      navItems={navItems} 
      title={title}
    >
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/staff" element={<Staff />} />
        <Route path="/staff/new" element={<StaffCreate />} />
        <Route path="/staff/organisation-structure" element={<OrganisationStructure />} />
        <Route path="/students" element={<Students />} />
        <Route path="/students/new" element={<StudentCreate />} />
        <Route path="/students/enroll" element={<StudentEnrollment />} />
        <Route path="/students/parents" element={<Parents />} />
        <Route path="/students/parents/new" element={<ParentCreate />} />
        <Route path="/attendance" element={<AttendanceHub />} />
        <Route path="/attendance/students" element={<AttendanceStudents />} />
        <Route path="/attendance/staff" element={<AttendanceStaff />} />
        <Route path="/attendance/config" element={<AttendanceConfig />} />
        <Route path="/academic/timetable" element={<Timetable />} />
        <Route path="/academic/school-days" element={<SchoolDays />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  );
}

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;
